package newpack;

/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 *
 * @author hduser
 */
import java.util.*; 

import java.io.IOException; 

 
import org.apache.hadoop.fs.*;
import org.apache.hadoop.io.*;
import org.apache.hadoop.mapred.*;
import org.apache.hadoop.util.*; 


  
import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.logging.Level;
import java.util.logging.Logger;

 

import java.sql.DriverManager;


/**
 *
 * 
 */


/**
 *
 * 
 */

public class newjob 
{ 
    
    
 //Main function 
   public static void main(String args[])throws Exception 
   { 
	 
      JobConf conf = new JobConf(newjob.class); 
      conf.setJobName("job"); 
      conf.setOutputKeyClass(Text.class);
      conf.setOutputValueClass(Text.class); 
      conf.setMapperClass(E_EMapper.class); 
      conf.setCombinerClass(E_EReduce.class); 
      conf.setReducerClass(E_EReduce.class); 
      conf.setInputFormat(TextInputFormat.class); 
      conf.setOutputFormat(TextOutputFormat.class); 
      FileInputFormat.setInputPaths(conf, new Path(args[0])); 
      FileOutputFormat.setOutputPath(conf, new Path(args[1])); 
      JobClient.runJob(conf); 
   }    
    
    


    

   //Mapper class 
   public static class E_EMapper extends MapReduceBase implements 
   Mapper<LongWritable ,/*Input key Type */ 
   Text,                /*Input value Type*/ 
   Text,                /*Output key Type*/ 
   Text>        /*Output value Type*/ 
   { 
      

        
        public void map(LongWritable key, Text value, OutputCollector<Text, Text> oc, Reporter rprtr) throws IOException 
        {
     String line = value.toString(); 
         String lasttoken = ""; 
         StringTokenizer s = new StringTokenizer(line," "); 
         String block = s.nextToken(); 
         
         while(s.hasMoreTokens())
            {
        	 System.out.println(block+"");
        	  oc.collect(new Text(block),new Text( s.nextToken() ));
              
            } 
           
//         int avgprice = Integer.parseInt(lasttoken); 
         
        }
   
   }
   //Reducer class 
   public static class E_EReduce extends MapReduceBase implements 
   Reducer< Text, Text, Text, Text > 
   {     
	    public Connection getcon() throws ClassNotFoundException, SQLException
	    { Connection con;
	    	  Class.forName("com.mysql.jdbc.Driver");
	          con=DriverManager.getConnection("jdbc:mysql://localhost:3306/satelite","root","");
	       
	   	         return con;
	        
	    }

  //double maxval=10.0;
        int ngmaxval=0;
        double thmean=220,thsd=30,thabdif=65,thmaxval=50;   
      //Reduce function 
      public void reduce( Text key, Iterator <Text> values, 
         OutputCollector<Text, Text> output, Reporter reporter) throws IOException 
         { 
               
        Statement st=null;
        Connection con;
      try {
          con = getcon();
          st=con.createStatement();
      } catch (ClassNotFoundException ex) {
          Logger.getLogger(newjob.class.getName()).log(Level.SEVERE, null, ex);
      } catch (SQLException ex) {
          Logger.getLogger(newjob.class.getName()).log(Level.SEVERE, null, ex);
      }
       
      
            
      String val[]=values.next().toString().split("\t");
                System.out.print(val[0]);
          
            // StringTokenizer s = new StringTokenizer(val,"_"); 
           // String []vals=    val.split("\\_");
            double mean=Double.parseDouble(val[0]);
            System.out.println(mean);
            double sd=Double.parseDouble(val[1].toString());
            double abdf=Double.parseDouble(val[2].toString());
            double mgmax=Double.parseDouble(val[3].toString());
            System.out.println(mgmax);
            double fid=Double.parseDouble(val[4].toString());
            System.out.println(fid);
//               if((val=values.next().get())>maxavg)
//                   { 
                  
//               } 
          
      	  
          
        try{    
        	System.out.println("nid is here");
        	Statement sst=getcon().createStatement();
        	//  sst.executeUpdate("insert into image_result values(null,'50','30','fire','psb')");
        	   ResultSet rs=sst.executeQuery("Select id from image_upload order by id desc");
        	   rs.next();
        	   String test[]=key.toString().split("-");
        	   if(fid!=0.0)
               {
        		   st.executeUpdate("insert into image_result values(null,'"+test[1]+"','"+test[0]+"','fire','psb')");
            	  
                 // st.executeUpdate("insert into img_upload values('"+test+"','"+key+"','fire','psb')");
                }
        	   else  if((mean<thmean&& sd>=thsd))
                   {
                    
        		   st.executeUpdate("insert into image_result values(null,'"+test[1]+"','"+test[0]+"','Land','psb')");
                      //st.executeUpdate("insert into img_upload values('"+test+"','"+key+"','Land','psb')");
                    }
                   else if ((mean>=thmean)&& (sd<thsd))
                   {
                       // Status_Bi.add("Sea");
                	   st.executeUpdate("insert into image_result values(null,'"+test[1]+"','"+test[0]+"','Sea','psb')");
                      // st.executeUpdate("insert into img_upload values('"+test+"','"+key+"','Sea','psb')");
                   }
                   else
                    {
                        if(abdf<thabdif && ngmaxval>thmaxval)
                        {
                        	//if(abdf<thabdif)
                            {
                            	 st.executeUpdate("insert into image_result values(null,'"+test[1]+"','"+test[0]+"','Sea','psb')");
                          // st.executeUpdate("insert into img_upload values('"+test+"','"+key+"','Sea','psb')");
                            }
                        }
                        else
                            {
                        	 st.executeUpdate("insert into image_result values(null,'"+test+"','"+key+"','Land','psb')");
                       // st.executeUpdate("insert into img_upload values('"+test+"','"+key+"','Land','psb')");
                            }
                    }
                  // output.collect(key,new Text("land"));
               
            }catch(Exception ex){
            	
            	
            	System.out.println(ex.getMessage()+"");
            } 
 
         } 
   
   
   }
   }
   